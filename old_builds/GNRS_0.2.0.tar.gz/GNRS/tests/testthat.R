library(testthat)
library(GNRS)


test_check("GNRS")
